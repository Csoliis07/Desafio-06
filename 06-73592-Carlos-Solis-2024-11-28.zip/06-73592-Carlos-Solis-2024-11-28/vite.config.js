export default {
    // config options
    css: {
        devSourcemap: true
    }
}